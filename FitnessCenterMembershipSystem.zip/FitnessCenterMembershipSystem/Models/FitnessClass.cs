﻿using System;
using System.Collections.Generic;

namespace FitnessCenterMembershipSystem.Models
{
    public class FitnessClass
    {
        public int ClassId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Schedule { get; set; }
        public ICollection<Member> Members { get; set; }
    }
}
