﻿using System.Collections.Generic;

namespace FitnessCenterMembershipSystem.Models
{
    public class Trainer
    {
        public int TrainerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Specialty { get; set; }
        public ICollection<FitnessClass> Classes { get; set; }
    }
}
